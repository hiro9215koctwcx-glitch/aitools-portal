>
> ⚠️ 此页面非字体下载页，仅为开发识别字体名称使用
>
> ⚠️ This page is not for downloading fonts; it is only used by developers to identify font names.

# IPAexGothic

## 📦 Package Info

| Property | Value |
|----------|-------|
| Package Name | `@fontpkg/ip-aex-gothic` |
| Display Name | IPAexGothic |
| Version | 002.01.0 |
| Total Size | 11.63 MB |
| File Count | 2 |

## 📁 Included Files

| File | Format | Size | Style |
|------|--------|------|-------|
| IPAexGothic.ttf | TTF | 5.82 MB | - |
| IPAexGothic.ttf | TTF | 5.82 MB | - |

## 🏷️ Font Names

| Field | en | ja |
|-------|-------|-------|
| preferredFamily | - | - |
| fontFamily | IPAexGothic | IPAexゴシック |
| fullName | IPAexGothic | IPAexゴシック |
| postscriptName | IPAexGothic | IPAexGothic |

## ℹ️ Font Information

| Property | Value |
|----------|-------|
| Version | Version 002.01 |
| Copyright | Copyright(c) Information-technology Promotion Agency, Japan (IPA), 2003-2012. You must accept "http://ipafont.ipa.go.jp/ipa_font_license_v1.html" to use this product. |
| License URL | http://ipafont.ipa.go.jp/ipa_font_license_v1.html |

## 🌍 Multi-language Names

### fullName

- **en**: IPAexGothic
- **ja**: IPAexゴシック

### postscriptName

- **en**: IPAexGothic
- **ja**: IPAexGothic

### fontFamily

- **en**: IPAexGothic
- **ja**: IPAexゴシック

### uniqueSubfamily

- **en**: IPAexGothic Version 002.01
- **ja**: IPAexGothic Version 002.01

### version

- **en**: Version 002.01
- **ja**: Version 002.01

### copyright

- **en**: Copyright(c) Information-technology Promotion Agency, Japan (IPA), 2003-2012. You must accept "http://ipafont.ipa.go.jp/ipa_font_license_v1.html" to use this product.
- **ja**: Copyright(c) Information-technology Promotion Agency, Japan (IPA), 2003-2012. You must accept "http://ipafont.ipa.go.jp/ipa_font_license_v1.html" to use this product.

### licenseURL

- **en**: http://ipafont.ipa.go.jp/ipa_font_license_v1.html
- **ja**: http://ipafont.ipa.go.jp/ipa_font_license_v1.html

